# Varry Studio — Android (Capacitor)

هذا المشروع يغلّف واجهة Varry Studio العربية داخل تطبيق Android باستخدام Capacitor 6.

## بناء APK عبر GitHub Actions

1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد، بما فيها `.github/workflows/build-android.yml`.
2. افتح تبويب **Actions** وشغّل **Build Android APK**، أو ادفع تحديثاً إلى فرع `main`.
3. بعد اكتمال العملية نزّل artifact باسم `varry-studio-debug-apk`، واستخرج `app-debug.apk` وثبّته على الهاتف. هذا بناء تجريبي للاستخدام الشخصي، وليس للنشر على Google Play.

## البناء محلياً

تحتاج Node.js وJava 17 وAndroid SDK مثبتاً ومهيأً.

```sh
npm ci
npx cap add android   # مرة واحدة فقط إذا لم يوجد مجلد android
npx cap sync android
cd android
./gradlew assembleDebug
```

يوجد التطبيق في `www/index.html`. بعد أي تعديل على الواجهة شغّل `npx cap sync android` قبل بناء APK.

## ملاحظات

- يستخدم التطبيق تخزين المتصفح المحلي (IndexedDB/localStorage). لا تنتقل البيانات تلقائياً من نسخة المتصفح؛ صدّر نسخة احتياطية من التطبيق القديم ثم استوردها هنا.
- بعض الخطوط والوظائف تعتمد على اتصال الإنترنت. قد تختلف الطباعة وتنزيل الملفات عن متصفح سطح المكتب.
- معرّف التطبيق: `com.varry.studio`.
