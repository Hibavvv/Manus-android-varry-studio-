package com.varry.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
